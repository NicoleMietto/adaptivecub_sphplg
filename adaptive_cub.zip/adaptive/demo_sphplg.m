function demo_sphplg

%This demo, given a list of 3 tolerances, a domain (example) and a function
%shows 5 graphs and a table containing the main datas.
%figure 1: minimal domain's triangolation.
%figure 2,3,4: domain's adaptive triangulation due to respectively first,
%              second and third tolerance in the list.
%figure 5: algebric cubature formula's (not adaptive) nodes with 40 as 
%          degree of exactness.

example=3;
function_type=4;
deg_rule=40;

[vertices,domain_str,V_i]=define_domain(example);
[f,fs]=define_function(function_type,vertices,V_i);

vertices=vertices./(vecnorm(vertices'))';
atol_list=[10^(-6); 10^(-9); 10^(-12)];

clf;

iter_list=[];
triang=[];
Ia=[];
AE=[];
RE=[];
tempo=[];

 for i=1:3
    atol=atol_list(i);
    rtol=atol;

    tic;
    [I,Ierr,flag,Ihigh,iters,tri_vertices,tri_conn_list,L1_vertices]=...
    adaptive_cub_sphpgon(vertices,f,atol,rtol);
    t_2=toc;

    [XW,tri_vertices,tri_conn_list]=cub_sphpgon(deg_rule,vertices);

    fX=feval(f,XW(:,1),XW(:,2),XW(:,3));
    Inum=(XW(:,4))'*fX;

    iter_list=[iter_list; iters];
    triang=[triang; length(L1_vertices)];
    Ia_string=sprintf('%1.15e', I);
    Ia=[Ia; Ia_string];
    AE=[AE; abs(I-Inum)];
    RE=[RE;abs(I-Inum)/Inum];
    tempo=[tempo; t_2];

    %prints some results
    if i==1
        fprintf('\n \t .....................');
        fprintf('\n \t '); disp(fs);
        fprintf('\n \t '); disp(domain_str);
        fprintf('\n \t ..... geometry .....');
        fprintf('\n \t vertices : %8.0f',size(tri_vertices,1)); 
        fprintf('\n \t triangle : %8.0f',size(tri_conn_list,1));
        fprintf('\n \t ...... rule .......');
        fprintf('\n \t pts      : %8.0f',size(XW,1));
        fprintf('\n \t In: %-1.15e',Inum);
        fprintf('\n \t ********************');
    end
    fprintf('\n \t --------------------');
    fprintf('\n \t TOL      : %1.15e',atol);
    fprintf('\n \t ..... adaptive .....');
    fprintf('\n \t iters    : %8.0f',iters); 
    fprintf('\n \t triangles: %8.0f',length(L1_vertices));  
    fprintf('\n \t ..... errors ......');
    fprintf('\n \t Ia: %-1.15e',I);
    fprintf('\n \t AE: %-1.15e',I-Inum);
    fprintf('\n \t RE: %-1.15e \n \n',(I-Inum)/Inum);
    fprintf('\n \t --------------------');

    %To create the coloured background
    Neval = 150000;
    N = 100000;
    xeval = PtsInSphPol(Neval,'S',vertices);
    p = haltonset(2);
    Xsq = net(p,N);
    Xsq = [2*Xsq(:,1)-1,2*pi*Xsq(:,2)];
    X = [sqrt(1-Xsq(:,1).^2).*cos(Xsq(:,2)), sqrt(1-Xsq(:,1).^2).*sin(Xsq(:,2)), Xsq(:,1)];
    F = f(xeval(:,1),xeval(:,2),xeval(:,3));
    %--------------------------------------------------------------

    if i==1
       figure(1)
       hold on;
       for k=1:size(tri_conn_list,1)
        
        con_L=tri_conn_list(k,:);
        tri_L=tri_vertices(con_L',:);
        tri_L(end+1,:)=tri_L(1,:);
        plot3(tri_L(:,1),tri_L(:,2),tri_L(:,3),'LineWidth',1.5);
       end
       if function_type==3
            plot3(V_i(1),V_i(2),V_i(3),'ko','MarkerFaceColor','k', ...
            'MarkerSize',4);
       end
       axis equal;
       if example==1
            view(215, 0);
       else
            view(0, 90);
       end
    end
    hold off;
    
    figure(i+1)

    scatter3(xeval(:,1),xeval(:,2),xeval(:,3),15,F,'o','filled','MarkerFaceAlpha',0.1,'MarkerEdgeAlpha',0.1)
    colormap summer
    colorbar
    axis equal;
    grid off;
    hold on;

    for k=1:length(L1_vertices)
      tri_L=L1_vertices{k};
      tri_L(end+1,:)=tri_L(1,:);
      plot3(tri_L(:,1),tri_L(:,2),tri_L(:,3),'r-','LineWidth',1.5);
      hold on;
    end
    if function_type==4
      plot3(V_i(1),V_i(2),V_i(3),'ko','MarkerFaceColor','k', ...
      'MarkerSize',4);
    end
    
    if example==1
            view(215, 0);
    else
            view(0, 90);
    end
    hold off;
    
end

figure(5)
    plot3(vertices(:,1),vertices(:,2),vertices(:,3),'mo',...
    'MarkerFaceColor','b', ...
    'MarkerSize',2);
    hold on;
    plot3(XW(:,1),XW(:,2),XW(:,3),'mo',...
    'MarkerFaceColor','m', ...
    'MarkerSize',2);
    axis equal;
    if example==1
            view(215, 0);
    else
            view(0, 90);
    end
    hold off;

T = table(atol_list, iter_list, triang, Ia, tempo, AE, RE, 'VariableNames', ...
    {'tol', 'iteraz.','triang.','Ia','time','AE','RE'});
display(T)

end





function [vertices,domain_str,V_i]=define_domain(example)

%--------------------------------------------------------------------------
% Object:
% This routine, defines the domain to analyse.
%--------------------------------------------------------------------------
% Input:
% example: determines the spherical polygon domain to be analysed. From 1
%   to 3.
%--------------------------------------------------------------------------
% Output:
% vertices: it is a matrix whose rows are the vertices of the spherical
%           triangles.
% domain_str: string that stores the geometry of the region.
% V_i: f_4's singularity vertice.
%--------------------------------------------------------------------------


switch example

    case 1

        % Australia island (no Tasmania), vertices in degrees.
        % Column 1: Longitude. Column 2: Latitude.
        % Planar domain in polyshape form.
        australia_pshape=coastline_australia(0);
        vertices_degs=australia_pshape.Vertices;

        % Australia vertices in radians.
        longitudes=deg2rad(vertices_degs(:,1));
        latitudes=deg2rad(vertices_degs(:,2));

        % Australia vertices in cartesian coordinates.
        [XX,YY,ZZ] = sph2cart(longitudes,latitudes,1);
        vertices=[XX YY ZZ];
        V_i=[XX(33) YY(33) ZZ(33)];

        domain_str='Australia as island (170 vertices, via polyshape)';
    
     case 2
        spec_settings=32;
        th=linspace(0,2*pi,spec_settings+1);
        polygon_sides=[cos(th').*(1-cos(th')) sin(th').*(1-cos(th'))];
        polygon_sides=polygon_sides(1:end-1,:);
        XV=polygon_sides(:,1); XV=XV/2.1;
        YV=polygon_sides(:,2); YV=YV/2.1;
        ZV=sqrt(1-XV.^2-YV.^2);
        vertices=[XV YV ZV];
        V_i=[0 0 1];

        domain_str='Polygonal cardioid at North-Pole';
    
    case 3
        vertices = [[0.4045    0.2939    0.8660];
                    [0.2676    0.8236    0.5000];
                    [-0.1545    0.4755    0.8660];
                    [-0.7006    0.5090    0.5000];
                    [-0.5000    0.0000    0.8660];
                    [-0.7006   -0.5090    0.5000];
                    [-0.1545   -0.4755    0.8660];
                    [0.2676   -0.8236    0.5000];
                    [0.4045   -0.2939    0.8660];
                    [0.8660   -0.0000    0.5000]];
        
        domain_str='decagono';
        V_i=vertices(1,:);
end
end

function [f,fs]=define_function(function_type,vertices,V_i)

%--------------------------------------------------------------------------
% Object:
% This routine, defines a function "f" to approximate and a string "fs" for
% possible messages to the user.
%--------------------------------------------------------------------------
% Input:
% function_type: determines the function to study.
% vertices: domain's vertices
% V_i: f_4's singularity
%--------------------------------------------------------------------------
% Output:
% f: defines a function "f" to approximate;
% fs: string with the content of the function "f".
%--------------------------------------------------------------------------
% Reference paper:
% A. Sommariva and M. Vianello
% Numerical hyperinterpolation overspherical triangles
%--------------------------------------------------------------------------

% ... centroid computation ...
ok_vertices=find( isnan(vertices(:,1))== 0 & ...
isnan(vertices(:,2)) == 0 );
vertices=vertices(ok_vertices,:);
centroid=sum(vertices,1); centroid=centroid/norm(centroid);
x0=centroid(1); y0=centroid(2); z0=centroid(3);

switch function_type

    case 1
        % ... function ...
        g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
        f=@(x,y,z) exp( -g(x,y,z));
        fs=['exp(-g(x,y,z))' ...
            ' g=@(x,y,z) (x-x0).^2+(y-y0).^2+(z-z0).^2'];

        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs=['exp(-g(x,y,z))' ...
            ' g(x,y,z) = (x-x0).^2+(y-y0).^2+(z-z0).^2'];
        fs=strcat(fs,'  centroid=(',x0str,',',y0str,',',z0str,')');

    case 2
        
        % ... function ...
        g=@(x,y,z) (x-x0).^2 + (y-y0).^2 + (z-z0).^2;
        f=@(x,y,z) exp( -g(x,y,z)).*(sin(10.*y+20*z)).^2.*cos(10.*x+20*z).^2;
        fs=['exp(-g(x,y,z)).*(sin(10.*x)).^2.*cos(10.*x).^2,' ...
            ' g=@(x,y,z) (x-x0).^2+(y-y0).^2+(z-z0).^2'];

        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs=['exp(-g(x,y,z)).*(sin(10.*x)).^2.*cos(10.*x).^2' ...
            ' g(x,y,z) = (x-x0).^2+(y-y0).^2+(z-z0).^2'];
        fs=strcat(fs,'  centroid=(',x0str,',',y0str,',',z0str,')');

    case 3 % centroid distance like

        % ... function ...
        f=@(x,y,z) ((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(1/2);

        % ... output string ...
        x0str=num2str(x0,'%1.3e');
        y0str=num2str(y0,'%1.3e');
        z0str=num2str(z0,'%1.3e');
        fs='((x-x0).^2 + (y-y0).^2 + (z-z0).^2).^(1/2), ';
        fs=strcat(fs,'  centroid=(',x0str,',',y0str,',',z0str,')');

    case 4

        % ... function ...
        f=@(x,y,z) ((x-V_i(1)).^2 + (y-V_i(2)).^2 + (z-V_i(3)).^2).^(1/4);

        % ... output string ...
        x0str=num2str(V_i(1),'%1.3e');
        y0str=num2str(V_i(2),'%1.3e');
        z0str=num2str(V_i(3),'%1.3e');
        fs='((x-V_i(1)).^2 + (y-V_i(2)).^2 + (z-V_i(3)).^2).^(1/4), ';
        fs=strcat(fs,'  V_i=(',x0str,',',y0str,',',z0str,')');

    
end  % end: "define_function"

end
